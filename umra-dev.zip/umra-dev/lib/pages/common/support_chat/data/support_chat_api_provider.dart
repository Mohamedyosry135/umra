// ignore: one_member_abstracts

import 'package:umra/base/base_auth_provider.dart';
import 'package:get/get.dart';


abstract class ISupportChatProvider {


}

class SupportChatProvider extends BaseAuthProvider implements ISupportChatProvider {

}
