class ProviderImages {
  static String _package() => "assets/provider/images/";


  static String hand() => "${_package()}hand.png";



}