

import 'package:umra/base/base_auth_provider.dart';



abstract class ISettingsProvider {


}

class SettingsProvider extends BaseAuthProvider implements ISettingsProvider {

}
