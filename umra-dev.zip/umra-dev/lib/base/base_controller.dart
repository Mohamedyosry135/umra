import 'package:get/get.dart';

abstract class BaseController<T> extends SuperController<T> {}
