

import 'package:umra/base/base_auth_provider.dart';



abstract class IChangeDayProvider {


}

class ChangeDayProvider extends BaseAuthProvider implements IChangeDayProvider {

}
