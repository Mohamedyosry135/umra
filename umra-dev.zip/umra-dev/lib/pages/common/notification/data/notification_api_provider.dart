import 'package:umra/base/base_auth_provider.dart';

abstract class INotificationApiProvider {

}

class NotificationApiProvider extends BaseAuthProvider implements INotificationApiProvider {

}
