class UserImages {
  static String _package() => "assets/user/images/";


  static String hand() => "${_package()}hand.png";
}