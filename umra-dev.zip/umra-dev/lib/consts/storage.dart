

class StorageKeys {
  static const userDataBox = "userData";
  static const appDataBox = "appData";
  static const userDataKey = "userData";
  static const showOnBoardKey = "showOnBoard";
  static const appLanguage = 'appLanguage';
  static const language = 'language';
  static const userImageDataBox = "userImageData";
  static const userImageDataKey = "userImageDataKey";


}

