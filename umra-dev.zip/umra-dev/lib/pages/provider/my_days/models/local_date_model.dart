class LocalDateModel {
  String? date;
  int? umraCount;
  LocalDateModel({this.date,this.umraCount});
}