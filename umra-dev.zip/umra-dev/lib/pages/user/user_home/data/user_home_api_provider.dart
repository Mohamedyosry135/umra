import 'package:umra/base/base_auth_provider.dart';

abstract class IUserHomeApiProvider {

}

class UserHomeApiProvider extends BaseAuthProvider implements IUserHomeApiProvider {

}
