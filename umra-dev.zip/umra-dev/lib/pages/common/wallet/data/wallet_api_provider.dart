

import 'package:umra/base/base_auth_provider.dart';



abstract class IWalletProvider {


}

class WalletProvider extends BaseAuthProvider implements IWalletProvider {

}
