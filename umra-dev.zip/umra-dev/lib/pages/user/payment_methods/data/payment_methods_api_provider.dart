import 'package:umra/base/base_auth_provider.dart';

abstract class IPaymentMethodsApiProvider {

}

class PaymentMethodsApiProvider extends BaseAuthProvider implements IPaymentMethodsApiProvider {

}
