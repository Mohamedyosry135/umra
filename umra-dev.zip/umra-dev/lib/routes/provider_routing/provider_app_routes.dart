part of 'provider_app_pages.dart';

abstract class ProviderRoutes {
  static const MY_DAYS = '/my_days';
  static const MY_REQUESTS = '/my-requests';
    static const PROVIDER_TRACK_ORDER = '/provider-track-order';



}
