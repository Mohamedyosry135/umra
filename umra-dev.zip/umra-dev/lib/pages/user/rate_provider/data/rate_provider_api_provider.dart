import 'package:umra/base/base_auth_provider.dart';

abstract class IRateProivderApiProvider {

}

class RateProivderApiProvider extends BaseAuthProvider implements IRateProivderApiProvider {

}
